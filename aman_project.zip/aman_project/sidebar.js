// sidebar.js — shared across all pages

const LANG = localStorage.getItem("amanLang") || "en";
const TOKEN = localStorage.getItem("amanToken");
const USER  = JSON.parse(localStorage.getItem("amanUser") || "null");

const T = {
  en: {
    newChat: "New Chat", home: "Home", settings: "Settings", search: "Search",
    general: "General", recentChats: "Recent Chats", login: "Login",
    logout: "Logout", loggedInAs: "Logged in as",
    // aman.html
    welcomeTitle: "Welcome to Aman.ai",
    welcomeDesc: "Upload your SDLC phase documents to receive a professional security analysis report for each phase.",
    hct: "Higher Colleges of Technology",
    tagline: "AI-Driven Software Security Analyst Assistant",
    startChat: "Start a new conversation and ask Aman.ai about your software security, vulnerabilities, or best practices.",
    analyze: "Analyze", downloadReport: "Download Report",
    generateFinal: "Generate Final Comprehensive Security Report",
    downloadFinal: "Download Final Report",
    analyzing: "Analyzing", generating: "Generating...", downloading: "Downloading...",
    // newchat.html
    conversation: "Conversation",
    convDesc: "Ask Aman.ai anything about software security.",
    msgPlaceholder: "Message Aman.ai...",
    helloMsg: "Hello! I'm Aman.ai. Ask me anything about software security, or attach a file for analysis.",
    // settings.html
    settingsTitle: "Settings", settingsDesc: "Manage your preferences for Aman.ai.",
    theme: "Theme", dark: "Dark (Default)", light: "Light",
    language: "Language", english: "English", arabic: "Arabic",
    clearHistory: "Clear Chat History", clearBtn: "Clear All History",
    saveSettings: "Save Settings", backHome: "← Back to Home",
    saved: "✓ Settings saved successfully.",
    // search.html
    searchTitle: "Search", searchDesc: "Search through your previous Aman.ai conversations.",
    searchLabel: "Search query", searchPlaceholder: "Search conversations...",
    searchBtn: "Search",
  },
  ar: {
    newChat: "محادثة جديدة", home: "الرئيسية", settings: "الإعدادات", search: "بحث",
    general: "عام", recentChats: "المحادثات الأخيرة", login: "تسجيل الدخول",
    logout: "تسجيل الخروج", loggedInAs: "مسجل دخول كـ",
    // aman.html
    welcomeTitle: "مرحباً بك في Aman.ai",
    welcomeDesc: "ارفع وثائق مراحل دورة حياة تطوير البرمجيات للحصول على تقرير أمني احترافي لكل مرحلة.",
    hct: "كليات التقنية العليا",
    tagline: "مساعد ذكاء اصطناعي لتحليل أمن البرمجيات",
    startChat: "ابدأ محادثة جديدة واسأل Aman.ai عن أمن البرمجيات.",
    analyze: "تحليل", downloadReport: "تحميل التقرير",
    generateFinal: "إنشاء التقرير الأمني الشامل النهائي",
    downloadFinal: "تحميل التقرير النهائي",
    analyzing: "جارٍ التحليل", generating: "جارٍ الإنشاء...", downloading: "جارٍ التحميل...",
    // newchat.html
    conversation: "المحادثة",
    convDesc: "اسأل Aman.ai عن أمن البرمجيات.",
    msgPlaceholder: "اكتب رسالتك...",
    helloMsg: "مرحباً! أنا Aman.ai. اسألني أي شيء عن أمن البرمجيات.",
    // settings.html
    settingsTitle: "الإعدادات", settingsDesc: "إدارة تفضيلاتك في Aman.ai.",
    theme: "المظهر", dark: "داكن (افتراضي)", light: "فاتح",
    language: "اللغة", english: "الإنجليزية", arabic: "العربية",
    clearHistory: "مسح سجل المحادثات", clearBtn: "مسح الكل",
    saveSettings: "حفظ الإعدادات", backHome: "→ العودة للرئيسية",
    saved: "✓ تم حفظ الإعدادات بنجاح.",
    // search.html
    searchTitle: "بحث", searchDesc: "ابحث في محادثاتك السابقة مع Aman.ai.",
    searchLabel: "نص البحث", searchPlaceholder: "ابحث في المحادثات...",
    searchBtn: "بحث",
  }
};

const t = (key) => (T[LANG] || T.en)[key] || key;

// Apply RTL + font for Arabic
function applyLang() {
  if (LANG === "ar") {
    document.documentElement.setAttribute("dir", "rtl");
    document.documentElement.setAttribute("lang", "ar");
    document.body.style.fontFamily = "'Segoe UI', Tahoma, Arial, sans-serif";
  } else {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.setAttribute("lang", "en");
  }
}

// Apply saved theme
function applyTheme() {
  if (localStorage.getItem("amanTheme") === "light") {
    document.body.classList.add("theme-light");
  } else {
    document.body.classList.remove("theme-light");
  }
}

function logout() {
  if (TOKEN) {
    fetch("http://localhost:8000/api/logout", {
      method: "POST", headers: { Authorization: "Bearer " + TOKEN }
    });
  }
  localStorage.removeItem("amanToken");
  localStorage.removeItem("amanUser");
  window.location.href = "login.html";
}

async function loadSidebarSessions(containerId, activeSessionId) {
  if (!TOKEN) return;
  try {
    const res = await fetch("http://localhost:8000/api/chat/sessions", {
      headers: { Authorization: "Bearer " + TOKEN }
    });
    const data = await res.json();
    const container = document.getElementById(containerId);
    if (!container) return;

    // Remove old session buttons (keep the section title)
    container.querySelectorAll(".session-btn").forEach(b => b.remove());

    data.sessions.forEach(s => {
      const btn = document.createElement("button");
      btn.className = "sidebar-btn session-btn" + (s.id === activeSessionId ? " active-session" : "");
      btn.style.cssText = "font-size:12px; padding:8px 10px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;";
      btn.title = s.title;
      btn.textContent = s.title;
      btn.onclick = () => { window.location.href = `newchat.html?session=${s.id}`; };
      container.appendChild(btn);
    });
  } catch {}
}

function buildSidebar(options = {}) {
  // options: { activePage, activeSessionId, sessionsContainerId }
  const activePage = options.activePage || "";
  const sessionsContainerId = options.sessionsContainerId || "sessionsList";

  // Auth block
  const authEl = document.getElementById("sidebarAuth");
  if (authEl) {
    if (USER) {
      authEl.innerHTML = `
        <span style="font-size:12px;color:#8b92b8;">${t("loggedInAs")}<br>
        <strong style="color:#e5e7ff;">${USER.email}</strong></span>
        <button class="sidebar-btn" style="margin-top:8px;" onclick="logout()">
          <span class="icon">🚪</span> ${t("logout")}
        </button>`;
    } else {
      authEl.innerHTML = `<a class="login-bottom" href="login.html">${t("login")}</a>`;
    }
  }

  // Translate static sidebar buttons by data-key
  document.querySelectorAll("[data-tkey]").forEach(el => {
    el.textContent = t(el.getAttribute("data-tkey"));
  });

  // Load sessions list
  loadSidebarSessions(sessionsContainerId, options.activeSessionId || null);
}
