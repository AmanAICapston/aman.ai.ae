# How to run fastapi

**Windows**

```
python -m venv venv
venv\Scripts\activate
```

1. Install dependencies:

```
pip install -r requirements.txt
```

------

## Run the Application

If your entry file is `main.py`:

```
uvicorn main:app --reload
```